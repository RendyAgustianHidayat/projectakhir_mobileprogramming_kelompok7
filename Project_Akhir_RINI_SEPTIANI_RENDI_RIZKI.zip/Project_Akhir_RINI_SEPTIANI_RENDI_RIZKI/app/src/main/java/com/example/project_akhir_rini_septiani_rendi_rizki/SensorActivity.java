package com.example.project_akhir_rini_septiani_rendi_rizki;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SensorActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private TextView tvCounter, tvValues;

    private int movementCounter = 0;
    private float lastX, lastY, lastZ;
    private long lastUpdateTime = 0;
    private static final int SHAKE_THRESHOLD = 800; // semakin kecil, semakin sensitif

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor);

        tvCounter = findViewById(R.id.tvCounter);
        tvValues = findViewById(R.id.tvValues);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (accelerometer != null)
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];

        tvValues.setText("X: " + x + "\nY: " + y + "\nZ: " + z);

        long currentTime = System.currentTimeMillis();
        if ((currentTime - lastUpdateTime) > 200) {
            long diffTime = currentTime - lastUpdateTime;
            lastUpdateTime = currentTime;

            float speed = Math.abs(x + y + z - lastX - lastY - lastZ) / diffTime * 10000;

            if (speed > SHAKE_THRESHOLD) {
                movementCounter++;
                tvCounter.setText("Gerakan: " + movementCounter);
            }

            lastX = x;
            lastY = y;
            lastZ = z;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Tidak digunakan
    }
}

