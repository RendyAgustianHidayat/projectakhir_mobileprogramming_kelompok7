package com.example.project_akhir_rini_septiani_rendi_rizki.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventoryDB";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE inventory (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nama_barang TEXT NOT NULL, " +
                "jenis_barang TEXT NOT NULL, " +
                "jumlah_barang INTEGER NOT NULL);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS inventory");
        onCreate(db);
    }

    public boolean insertData(String nama, String jenis, int jumlah) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nama_barang", nama);
        values.put("jenis_barang", jenis);
        values.put("jumlah_barang", jumlah);
        long result = db.insert("inventory", null, values);
        return result != -1;
    }

    public List<Barang> getAllBarang() {
        List<Barang> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM inventory", null);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String nama = cursor.getString(1);
                String jenis = cursor.getString(2);
                int jumlah = cursor.getInt(3);
                list.add(new Barang(id, nama, jenis, jumlah));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public void deleteData(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("inventory", "id=?", new String[]{String.valueOf(id)});
    }

    public void updateData(int id, String nama, String jenis, int jumlah) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nama_barang", nama);
        values.put("jenis_barang", jenis);
        values.put("jumlah_barang", jumlah);

        db.update("inventory", values, "id=?", new String[]{String.valueOf(id)});
    }

}
