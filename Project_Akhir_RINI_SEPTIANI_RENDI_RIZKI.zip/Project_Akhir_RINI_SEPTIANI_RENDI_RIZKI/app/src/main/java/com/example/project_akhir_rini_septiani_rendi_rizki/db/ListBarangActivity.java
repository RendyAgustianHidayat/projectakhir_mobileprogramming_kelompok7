package com.example.project_akhir_rini_septiani_rendi_rizki.db;


import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;


import com.example.project_akhir_rini_septiani_rendi_rizki.R;

import java.util.List;

public class ListBarangActivity extends AppCompatActivity {

    ListView listView;
    BarangAdapter adapter;
    List<Barang> barangList;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_barang); // atau activity_list_barang

        listView = findViewById(R.id.listView);
        db = new DatabaseHelper(this);
        barangList = db.getAllBarang();

        adapter = new BarangAdapter(this, barangList, db);
        listView.setAdapter(adapter);
    }
}