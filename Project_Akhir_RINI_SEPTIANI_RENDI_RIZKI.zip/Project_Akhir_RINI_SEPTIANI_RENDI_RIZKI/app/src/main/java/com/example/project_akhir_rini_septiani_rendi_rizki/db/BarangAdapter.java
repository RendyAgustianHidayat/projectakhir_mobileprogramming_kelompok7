package com.example.project_akhir_rini_septiani_rendi_rizki.db;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;


import com.example.project_akhir_rini_septiani_rendi_rizki.R;

import java.util.List;

public class BarangAdapter extends BaseAdapter {
    private Context context;
    private List<Barang> barangList;
    private DatabaseHelper db;

    public BarangAdapter(Context context, List<Barang> list, DatabaseHelper db) {
        this.context = context;
        this.barangList = list;
        this.db = db;
    }

    @Override
    public int getCount() {
        return barangList.size();
    }

    @Override
    public Object getItem(int position) {
        return barangList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return barangList.get(position).id;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Barang b = barangList.get(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_barang, parent, false);
        }

        TextView tvNama = convertView.findViewById(R.id.tvNama);
        TextView tvJenis = convertView.findViewById(R.id.tvJenis);
        TextView tvJumlah = convertView.findViewById(R.id.tvJumlah);
        Button btnDelete = convertView.findViewById(R.id.btnDelete);
        Button btnUpdate = convertView.findViewById(R.id.btnUpdate);

        tvNama.setText(b.namaBarang);
        tvJenis.setText(b.jenisBarang);
        tvJumlah.setText("Jumlah: " + b.jmlBarang);

        btnDelete.setOnClickListener(v -> {
            db.deleteData(b.id);
            barangList.remove(position);
            notifyDataSetChanged();
            Toast.makeText(context, "Data dihapus", Toast.LENGTH_SHORT).show();
        });

        btnUpdate.setOnClickListener(v -> {
//            Toast.makeText(context, "Update barang: " + b.namaBarang, Toast.LENGTH_SHORT).show();
            // Dialog update bisa ditambahkan di sini
            showUpdateDialog(b, position);

        });

        return convertView;
    }

    private void showUpdateDialog(Barang barang, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Update Barang");

        View view = LayoutInflater.from(context).inflate(R.layout.dialog_update_barang, null);
        builder.setView(view);

        EditText etNama = view.findViewById(R.id.etNamaUpdate);
        EditText etJenis = view.findViewById(R.id.etJenisUpdate);
        EditText etJumlah = view.findViewById(R.id.etJumlahUpdate);

        // Pre-fill
        etNama.setText(barang.namaBarang);
        etJenis.setText(barang.jenisBarang);
        etJumlah.setText(String.valueOf(barang.jmlBarang));

        builder.setPositiveButton("Simpan", (dialog, which) -> {
            String namaBaru = etNama.getText().toString();
            String jenisBaru = etJenis.getText().toString();
            int jumlahBaru = Integer.parseInt(etJumlah.getText().toString());

            // Update ke DB
            db.updateData(barang.id, namaBaru, jenisBaru, jumlahBaru);

            // Update ke list
            barang.namaBarang = namaBaru;
            barang.jenisBarang = jenisBaru;
            barang.jmlBarang = jumlahBaru;
            notifyDataSetChanged();

            Toast.makeText(context, "Data diperbarui", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Batal", null);
        builder.show();
    }

}

