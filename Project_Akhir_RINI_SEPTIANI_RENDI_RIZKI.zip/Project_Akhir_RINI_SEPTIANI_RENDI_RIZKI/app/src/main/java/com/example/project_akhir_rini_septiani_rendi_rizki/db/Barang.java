package com.example.project_akhir_rini_septiani_rendi_rizki.db;

public class Barang {
    public int id;
    public String namaBarang;
    public String jenisBarang;
    public int jmlBarang;

    public Barang(int id,String namaBarang, String jenisBarang, int jmlBarang){
        this.id = id;
        this.namaBarang = namaBarang;
        this.jenisBarang = jenisBarang;
        this.jmlBarang = jmlBarang;
    }
}
