package com.example.project_akhir_rini_septiani_rendi_rizki.db;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.project_akhir_rini_septiani_rendi_rizki.R;

public class InputBarangActivity extends AppCompatActivity {

    EditText etNamaBarang, etJenisBarang, etJumlahBarang;
    Button btnSimpan;
    DatabaseHelper db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_barang);

        etNamaBarang = findViewById(R.id.etNamaBarang);
        etJenisBarang = findViewById(R.id.etJenisBarang);
        etJumlahBarang = findViewById(R.id.etJumlahBarang);
        btnSimpan = findViewById(R.id.btnSimpan);

        db = new DatabaseHelper(this);

        btnSimpan.setOnClickListener(v -> {
            String nama = etNamaBarang.getText().toString();
            String jenis = etJenisBarang.getText().toString();
            String jumlahStr = etJumlahBarang.getText().toString();

            if (nama.isEmpty() || jenis.isEmpty() || jumlahStr.isEmpty()) {
                Toast.makeText(this, "Semua field wajib diisi", Toast.LENGTH_SHORT).show();
                return;
            }

            int jumlah = Integer.parseInt(jumlahStr);
            boolean berhasil = db.insertData(nama, jenis, jumlah);

            if (berhasil) {
                Toast.makeText(this, "Data berhasil disimpan", Toast.LENGTH_SHORT).show();
                etNamaBarang.setText("");
                etJenisBarang.setText("");
                etJumlahBarang.setText("");
            } else {
                Toast.makeText(this, "Gagal menyimpan data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}