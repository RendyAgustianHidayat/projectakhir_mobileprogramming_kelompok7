package com.example.project_akhir_rini_septiani_rendi_rizki;

import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import android.Manifest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.osmdroid.api.IMapController;
import org.osmdroid.config.Configuration;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;

public class MapActivity extends AppCompatActivity {

    private static final int
            REQUEST_PERMISSIONS_REQUEST_CODE = 1;
    private MapView map;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        //komfigurasi penggunaan osmdroid

        Configuration.getInstance().load(getApplicationContext(
                ),
                getSharedPreferences("osmdroid",
                        MODE_PRIVATE));
        // Load konfigurasi osmdroid (gunakan contextaplikasi)
        setContentView(R.layout.activity_map2);
        map = findViewById(R.id.map2);
        map.setMultiTouchControls(true);
        if (!hasPermissions()) {
            requestPermissions();
        } else {
            setupMap();
        }
    }
    private boolean hasPermissions() {
        return ContextCompat.checkSelfPermission(this,

                Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this,
                Manifest.permission.INTERNET) ==
                PackageManager.PERMISSION_GRANTED;
    }
    private void requestPermissions() {
        ActivityCompat.requestPermissions(this,
                new String[]{

                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.INTERNET
                },

                REQUEST_PERMISSIONS_REQUEST_CODE);
    }
    private void setupMap() {
        IMapController mapController =
                map.getController();
        mapController.setZoom(15.0);
        GeoPoint startPoint = new GeoPoint(-6.2088,
                106.8456); // Jakarta
        mapController.setCenter(startPoint);
    }
    @Override
    public void onRequestPermissionsResult(int
                                                   requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode ==
                REQUEST_PERMISSIONS_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0]
                    == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission granted",
                        Toast.LENGTH_SHORT).show();
                setupMap();
            } else {
                Toast.makeText(this, "Permission denied",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        map.onResume();
    }
    @Override
    protected void onPause() {
        super.onPause();
        map.onPause();
    }
}