package com.example.project_akhir_rini_septiani_rendi_rizki;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;


import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.project_akhir_rini_septiani_rendi_rizki.db.InputBarangActivity;
import com.example.project_akhir_rini_septiani_rendi_rizki.db.ListBarangActivity;
import com.google.android.material.navigation.NavigationView;

public class DashboardActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    CardView cardSensor, cardMaps, cardAdd, cardListBarang;

    DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);


        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitleTextColor(Color.parseColor("white"));
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this,drawer,toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);

        drawer.addDrawerListener(toggle);
        toggle.syncState();

        cardSensor = findViewById(R.id.cardSensor);
        cardMaps = findViewById(R.id.cardMaps);
        cardAdd = findViewById(R.id.cardInput);
        cardListBarang = findViewById(R.id.cardListBarang);

        cardSensor.setOnClickListener(v -> {
            startActivity(new Intent(DashboardActivity.this, SensorActivity.class));
        });

        cardMaps.setOnClickListener(v -> {
            startActivity(new Intent(DashboardActivity.this, MapActivity.class));
        });

        cardAdd.setOnClickListener(v -> {
            startActivity(new Intent(DashboardActivity.this, InputBarangActivity.class));
        });

        cardListBarang.setOnClickListener(v -> {
            startActivity(new Intent(DashboardActivity.this, ListBarangActivity.class));
        });
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_dashboard) {
            drawer.closeDrawer(GravityCompat.START);
        } else if (id == R.id.nav_tambah) {
            startActivity(new Intent(DashboardActivity.this, InputBarangActivity.class));
        } else if (id == R.id.nav_lihat) {
            startActivity(new Intent(DashboardActivity.this, ListBarangActivity.class));
        } else if (id == R.id.nav_keluar) {
            finish();
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

}
